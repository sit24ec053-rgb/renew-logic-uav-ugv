// RENEW-LOGIC sensor monitoring firmware extracted from the project report.
// Verify pin assignments and calibrate thresholds for your actual hardware.

#include <DHT.h>


// Sensor pin configuration
#define TRIG_PIN 5
#define ECHO_PIN 18
#define DHT_PIN 4
#define DHT_TYPE DHT22
#define GAS_PIN 34
#define BUZZER_PIN 19


DHT dht(DHT_PIN, DHT_TYPE);


// Example thresholds; calibrate before actual use
const float TEMP_LIMIT = 40.0;
const int GAS_LIMIT = 2000;
const float OBSTACLE_LIMIT = 20.0;


float getDistance() {
 digitalWrite(TRIG_PIN, LOW);
 delayMicroseconds(2);


 digitalWrite(TRIG_PIN, HIGH);
 delayMicroseconds(10);
 digitalWrite(TRIG_PIN, LOW);


 long duration = pulseIn(ECHO_PIN, HIGH, 30000);


 if (duration == 0) {
     return -1;
 }

    return duration * 0.0343 / 2.0;
}


void setup() {
    Serial.begin(115200);


    pinMode(TRIG_PIN, OUTPUT);
    pinMode(ECHO_PIN, INPUT);
    pinMode(GAS_PIN, INPUT);
    pinMode(BUZZER_PIN, OUTPUT);


    dht.begin();


    Serial.println("RENEW-LOGIC Monitoring Started");
}


void loop() {
    float temperature = dht.readTemperature();
    int gasValue = analogRead(GAS_PIN);
    float distance = getDistance();


    bool alert = false;


    Serial.println("\n--- Sensor Readings ---");


    if (isnan(temperature)) {
     Serial.println("Temperature sensor error");
    } else {
     Serial.print("Temperature: ");
     Serial.print(temperature);
     Serial.println(" C");


     if (temperature > TEMP_LIMIT) {

            Serial.println("WARNING: High temperature!");
            alert = true;
        }
    }


    Serial.print("Gas sensor reading: ");
    Serial.println(gasValue);


    if (gasValue > GAS_LIMIT) {
        Serial.println("WARNING: Gas threshold exceeded!");
        alert = true;
    }


    if (distance < 0) {
        Serial.println("Ultrasonic sensor reading unavailable");
    } else {
        Serial.print("Obstacle distance: ");
        Serial.print(distance);
        Serial.println(" cm");


        if (distance < OBSTACLE_LIMIT) {
            Serial.println("WARNING: Obstacle detected!");
            alert = true;
        }
    }


    digitalWrite(BUZZER_PIN, alert ? HIGH : LOW);


    delay(1000);
}
