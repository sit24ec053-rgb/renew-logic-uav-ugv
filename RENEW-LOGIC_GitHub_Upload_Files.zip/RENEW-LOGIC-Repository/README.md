# RENEW-LOGIC

**Hybrid UAV–UGV Based Smart Inspection System for Electrical Substations**

RENEW-LOGIC is an academic prototype concept that combines a ground vehicle (UGV) for accessible-area patrol and environmental sensing with a camera-equipped aerial vehicle (UAV) for elevated or inaccessible visual inspection. The design aims to reduce personnel exposure to hazardous inspection zones.

## Repository contents

- `docs/RENEW-LOGIC_Project_Report.pdf` — project report, including the blended model image and project documentation.
- `src/renew_logic_sensor_monitor.ino` — ESP32 sensor-monitoring sketch transcribed from the report appendix.
- `simulation/WOKWI_LINK.txt` — link to the Wokwi simulation.

## Main functions described

- Temperature monitoring using a DHT22 sensor.
- Gas-level monitoring using an analog MQ sensor input.
- Obstacle-distance measurement using an ultrasonic sensor.
- Threshold-based warnings through the serial monitor and buzzer.
- Proposed UAV camera inspection for elevated equipment.

## Simulation

Wokwi project: https://wokwi.com/projects/461375483386452993

**Important:** The report sketch and Wokwi simulation may not be identical. The `.ino` file in this repository is extracted from the report. For reproducibility, download the actual sketch and wiring diagram from Wokwi and add them as separate files after checking them.

## Hardware and safety notes

The temperature and gas thresholds in the sketch are example values and must be calibrated. This is an academic prototype, not a certified protection system. Do not connect or test it directly on energized high-voltage substation equipment.

## Status

Prototype design and simulation documentation. Add real test readings, wiring diagrams, and verified hardware photos as they become available; do not present planned tests as completed results.
